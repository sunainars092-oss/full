const products = [

{
  name:"Runner X",
  price:"$120"
},

{
  name:"Street Pro",
  price:"$99"
},

{
  name:"Gym Force",
  price:"$140"
},

{
  name:"Air Zoom",
  price:"$160"
}

];

const container =
document.getElementById("products");

products.forEach(item => {

container.innerHTML += `

<div class="card">

  <div class="shoe"></div>

  <h3>${item.name}</h3>

  <p class="price">
    ${item.price}
  </p>

  <button>
    Add To Cart
  </button>

</div>

`;

});